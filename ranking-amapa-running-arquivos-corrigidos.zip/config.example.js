// Copie para config.js e preencha APENAS com a URL e a chave publishable/anon.
// Nunca inclua service_role, senhas ou tokens privados no site.
window.RANKING_CONFIG = {
  supabaseUrl: 'https://SEU-PROJETO.supabase.co',
  supabaseAnonKey: 'SUA_CHAVE_PUBLICAVEL',
  temporada: 2027
};
