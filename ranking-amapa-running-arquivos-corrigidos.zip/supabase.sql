-- Ranking Amapá Running: execute no SQL Editor de um projeto Supabase novo.
-- MVP: categorias e faixas declaradas pelo atleta; validação documental pelo administrador.
create extension if not exists pgcrypto;
create table public.municipios (nome text primary key);
insert into public.municipios(nome) values ('Amapá'),('Calçoene'),('Cutias'),('Ferreira Gomes'),('Itaubal'),('Laranjal do Jari'),('Macapá'),('Mazagão'),('Oiapoque'),('Pedra Branca do Amapari'),('Porto Grande'),('Pracuúba'),('Santana'),('Serra do Navio'),('Tartarugalzinho'),('Vitória do Jari') on conflict do nothing;
create table public.athletes (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null check (length(trim(display_name)) between 2 and 90),
 municipio text not null references public.municipios(nome),
 categoria text not null check(categoria in ('Masculino','Feminino','PcD')),
 faixa text not null check(faixa in ('Até 17','18–29','30–39','40–49','50–59','60–69','70+')),
 classe_pcd text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check (categoria <> 'PcD' or nullif(trim(classe_pcd),'') is not null)
);
create table public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = '' as $$select exists(select 1 from public.admins where user_id=auth.uid())$$;
create table public.results (
 id uuid primary key default gen_random_uuid(),
 athlete_id uuid not null references public.athletes(id) on delete cascade,
 prova text not null check(length(trim(prova)) between 3 and 120),
 data_prova date not null,
 municipio_prova text not null references public.municipios(nome),
 distancia text not null check(distancia in ('5 km','10 km','21,0975 km','42,195 km')),
 tempo_seg integer not null check(tempo_seg between 1 and 172800),
 numero_peito text not null check(length(trim(numero_peito)) between 1 and 30),
 url_resultado text not null check(url_resultado ~ '^https://[^[:space:]]+$'),
 status text not null default 'pendente' check(status in ('pendente','aprovado','rejeitado')),
 motivo_revisao text,
 reviewed_by uuid references auth.users(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now(),
 unique(athlete_id, prova, data_prova, distancia)
);
create table public.review_log (
 id bigint generated always as identity primary key,
 result_id uuid not null references public.results(id) on delete cascade,
 reviewer_id uuid not null references auth.users(id),
 previous_status text not null,
 new_status text not null,
 note text,
 changed_at timestamptz not null default now()
);
create or replace function public.review_result(p_id uuid,p_status text,p_note text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare old_status text;
begin
 if not public.is_admin() then raise exception 'Acesso negado'; end if;
 if p_status not in ('aprovado','rejeitado') then raise exception 'Status inválido'; end if;
 select status into old_status from public.results where id=p_id for update;
 if not found then raise exception 'Resultado não encontrado'; end if;
 update public.results set status=p_status,motivo_revisao=left(p_note,500),reviewed_by=auth.uid(),reviewed_at=now() where id=p_id;
 insert into public.review_log(result_id,reviewer_id,previous_status,new_status,note) values(p_id,auth.uid(),old_status,p_status,left(p_note,500));
end $$;
-- Pontos demonstrativos por posição dentro da prova/distância/categoria/faixa/classe.
-- O regulamento deve definir empates, categorias PcD e provas elegíveis antes da temporada oficial.
create or replace view public.ranking_resultados with (security_invoker = true) as
select r.id,r.athlete_id,a.display_name,a.municipio,a.categoria,a.faixa,a.classe_pcd,
 r.prova,r.data_prova,r.municipio_prova,r.distancia,r.tempo_seg,
 dense_rank() over(partition by r.prova,r.data_prova,r.distancia,a.categoria,a.faixa,coalesce(a.classe_pcd,'') order by r.tempo_seg) as posicao_prova
from public.results r join public.athletes a on a.id=r.athlete_id where r.status='aprovado';
create or replace view public.ranking_pontos with (security_invoker = true) as
with scored as (
 select *, case when posicao_prova <= 10 then (11-posicao_prova)*10 else 5 end as pontos from public.ranking_resultados
), best10 as (
 select *,row_number() over(partition by athlete_id,distancia,extract(year from data_prova) order by pontos desc,tempo_seg asc,data_prova asc,id) as rn from scored
)
select athlete_id,display_name,municipio,categoria,faixa,classe_pcd,distancia,
 extract(year from data_prova)::integer as temporada,
 sum(pontos)::integer as pontos, count(*)::integer as provas
from best10 where rn<=10 group by athlete_id,display_name,municipio,categoria,faixa,classe_pcd,distancia,extract(year from data_prova);
create or replace view public.ranking_tempos with (security_invoker = true) as
select athlete_id,display_name,municipio,categoria,faixa,classe_pcd,distancia,
 extract(year from data_prova)::integer as temporada,min(tempo_seg)::integer as melhor_tempo
from public.ranking_resultados group by athlete_id,display_name,municipio,categoria,faixa,classe_pcd,distancia,extract(year from data_prova);
-- RLS: os atletas veem perfis públicos e apenas seus próprios envios não homologados.
alter table public.municipios enable row level security;
alter table public.athletes enable row level security;
alter table public.admins enable row level security;
alter table public.results enable row level security;
alter table public.review_log enable row level security;
create policy municipios_read on public.municipios for select to anon,authenticated using (true);
create policy athletes_read on public.athletes for select to anon,authenticated using (true);
create policy athletes_insert on public.athletes for insert to authenticated with check (id=auth.uid());
create policy athletes_update on public.athletes for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
create policy admins_read_self on public.admins for select to authenticated using(user_id=auth.uid());
create policy results_read on public.results for select to anon,authenticated using(status='aprovado' or athlete_id=auth.uid() or public.is_admin());
create policy results_insert on public.results for insert to authenticated with check(athlete_id=auth.uid() and status='pendente' and reviewed_by is null and reviewed_at is null);
create policy review_log_read on public.review_log for select to authenticated using(public.is_admin());
-- Não conceder UPDATE/DELETE de resultados diretamente ao cliente.
revoke all on public.review_log from anon,authenticated;
grant select on public.review_log to authenticated;
grant select on public.municipios,public.athletes,public.results,public.ranking_resultados,public.ranking_pontos,public.ranking_tempos to anon,authenticated;
grant insert,update on public.athletes to authenticated;
grant insert on public.results to authenticated;
grant select on public.admins to authenticated;
grant execute on function public.review_result(uuid,text,text) to authenticated;
-- Depois de cadastrar o administrador no Supabase Auth, execute MANUALMENTE:
-- insert into public.admins(user_id) values ('UUID-DO-ADMINISTRADOR');
