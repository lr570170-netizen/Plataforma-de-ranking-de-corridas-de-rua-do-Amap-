# Ranking Amapá Running — MVP com Supabase (configuração necessária)

Esta versão mantém as páginas de demonstração e adiciona **Plataforma real**: autenticação por e-mail/senha, perfil municipal, envio de resultado, fila de homologação com auditoria e rankings estaduais/municipais derivados exclusivamente de resultados aprovados. Os 16 municípios estão cadastrados no banco.

## Ativar

1. Crie um projeto no [Supabase](https://supabase.com/dashboard). Em **SQL Editor**, execute `supabase.sql` integralmente, em um projeto novo. Não execute sobre banco com tabelas de mesmo nome sem revisar.
2. Em **Project Settings → API**, copie **Project URL** e **anon/publishable key** para `config.js`. Essa chave é pública por definição; **NUNCA** use `service_role` ou secret key no navegador. Configure em **Authentication → URL Configuration** o domínio de produção `https://ranking-amapa-running.netlify.app` e os redirects permitidos. Ative confirmação de e-mail e proteção contra bots/rate limits.
3. Envie `index.html`, `style.css`, `app.js`, `live.js`, `config.js`, `netlify.toml` para a **raiz do repositório GitHub**, na branch `main`. Não envie `supabase.sql` como arquivo executável do site (pode guardá-lo em `database/`). O Netlify conectado deverá publicar a atualização.
4. Crie uma conta de administrador via formulário do site e confirme o e-mail. No Supabase, abra **Authentication → Users**, copie o UUID e execute manualmente no SQL Editor: `insert into public.admins(user_id) values ('UUID');`. Só então aparecerá a área de homologação.
5. Teste com dois usuários: um atleta envia um resultado; o administrador confere o link e aprova; o ranking de pontos e de tempos é recalculado por consultas ao banco. Filtre por município.

## Limitações importantes antes de lançar como serviço oficial

- **Não está configurado nem publicado automaticamente por este pacote**: exige seu projeto Supabase e envio ao GitHub. Até configurar, a nova aba avisa que falta conexão; as páginas antigas seguem como demo.
- **Regulamento provisório:** pontos 100,90,…,10 para posições 1–10 e 5 para demais, por prova + data + distância + categoria + faixa + classe PcD; melhores 10 resultados do atleta por distância e temporada. Empates, distância aferida, faixa etária por data de nascimento, classes esportivas PcD, prova elegível, recursos e migração de município exigem regras finais e validação. O ranking por tempos e por pontos não deve misturar distâncias/categorias na premiação.
- O perfil público usa nome de exibição, município, categoria, faixa e classe PcD. A classe PcD pode revelar dado sensível: obter consentimento explícito e revisar tratamento com encarregado LGPD antes de operação pública. Não solicitar laudos pelo protótipo.
- A classificação é atualizada ao **recarregar/abrir** a aba após homologação, não via WebSocket; não há push em tempo real. A pontuação é derivada de resultados aprovados no banco.
- Faltam validação forte de resultados, proteção antiabuso, gestão de eventos oficiais, testes de carga, políticas de privacidade, gestão de contas e exclusão, logs operacionais, backups e mecanismo de recurso. Este MVP é para **piloto controlado**, não certificação oficial.
- A interface consulta no máximo 2.000 linhas por ranking; para escala estadual deve migrar para consultas paginadas/agregações no servidor.
